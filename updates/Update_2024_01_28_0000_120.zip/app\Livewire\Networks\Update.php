<?php

namespace App\Livewire\Networks;

use Livewire\Component;

class Update extends Component
{
    public function render()
    {
        return view('livewire.networks.update');
    }
}
