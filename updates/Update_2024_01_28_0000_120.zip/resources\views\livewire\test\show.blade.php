<x-app-layout>
    error view code and resolve it in the table users !7
</x-app-layout>
